from django.apps import AppConfig


class TravelloAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Travello_App'
